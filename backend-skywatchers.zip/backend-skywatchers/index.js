const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const dotenv = require('dotenv');
const axios = require('axios');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

app.post('/search', (req, res) => {
  const { city } = req.body;
  const API_KEY = process.env.WEATHER_API_KEY;

  axios
    .get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`)
    .then((response) => {
      const weatherData = response.data;

      // Save search to the database
      const sql = 'INSERT INTO searches (city) VALUES (?)';
      db.query(sql, [city], (err) => {
        if (err) throw err;
      });

      res.json(weatherData);
    })
    .catch((error) => {
      console.error(error);
      res.status(500).send('Error fetching weather data');
    });
});

app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});