function calculateCountdown() {
  const today = new Date();
  const ramadanStart = new Date("2025-03-01");

  // Calculate difference in time
  const differenceInTime = ramadanStart - today;

  // Convert difference from milliseconds to days
  const daysRemaining = Math.ceil(differenceInTime / (1000 * 60 * 60 * 24));

  const countdownElement = document.getElementById("days-remaining");

  if (daysRemaining > 0) {
    countdownElement.innerText = `${daysRemaining} days remaining for Ramadan!`;
  } else {
    countdownElement.innerText = "Happy Ramadan!";
  }
}

// Call the function when the page loads
calculateCountdown();

// Task Management
const tasks = JSON.parse(localStorage.getItem("ramadanTasks")) || [];

function addTask() {
  const taskInput = document.getElementById("task-input").value;
  const taskTime = document.getElementById("task-time").value;
  if (taskInput === "" || taskTime === "") {
    alert("Please fill out the task and time!");
    return;
  }
  const task = {
    text: taskInput,
    time: taskTime,
    completed: false,
  };

  tasks.push(task);
  localStorage.setItem("ramadanTasks", JSON.stringify(tasks));
  renderTasks();
  document.getElementById("task-input").value = "";
  document.getElementById("task-time").value = "";
  
}


function renderTasks() {
  const taskContainer = document.getElementById("task-container");
  taskContainer.innerHTML = "";

  tasks.forEach((task, index) => {
    const li = document.createElement("li");

    const taskText = document.createElement("span");
    taskText.innerText = `${task.text}  ${task.time}`;
    if (task.completed) taskText.classList.add("done");

    const completeButton = document.createElement("button");
    completeButton.innerText = "✔";
    completeButton.onclick = () => {
      tasks[index].completed = !tasks[index].completed;
      localStorage.setItem("ramadanTasks", JSON.stringify(tasks));
      renderTasks();
    };

    const deleteButton = document.createElement("button");
    deleteButton.innerText = "🗑";
    deleteButton.onclick = () => {
      tasks.splice(index, 1);
      localStorage.setItem("ramadanTasks", JSON.stringify(tasks));
      renderTasks();
    };

    li.appendChild(taskText);
    li.appendChild(completeButton);
    li.appendChild(deleteButton);
    taskContainer.appendChild(li);
    
  });
}


// Render tasks on page load
renderTasks();

